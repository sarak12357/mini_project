import React from 'react'
import DashboardContainer from '../containers/Dashboard/DashboardContainer'

function Dashboard() {
  return (
    <DashboardContainer></DashboardContainer>
  )
}

export default Dashboard