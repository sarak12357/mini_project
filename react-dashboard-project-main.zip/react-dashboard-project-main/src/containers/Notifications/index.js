import NotificationsContainer from './NotificationsContainer'

export default NotificationsContainer;