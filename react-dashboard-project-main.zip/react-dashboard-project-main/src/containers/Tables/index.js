import TablesContainer from './TablesContainer'

export default TablesContainer;