import RTLContainer from './RTLContainer'

export default RTLContainer;